<?php

use Faker\Generator as Faker;

$factory->define(App\EliminacionCompetencia::class, function (Faker $faker) {
    return [
        //
    ];
});
