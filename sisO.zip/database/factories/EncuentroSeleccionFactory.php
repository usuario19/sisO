<?php

use Faker\Generator as Faker;

$factory->define(App\Encuentro_Seleccion::class, function (Faker $faker) {
    return [
        //
    ];
});
