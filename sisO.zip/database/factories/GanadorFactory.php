<?php

use Faker\Generator as Faker;

$factory->define(App\Ganador::class, function (Faker $faker) {
    return [
        //
    ];
});
