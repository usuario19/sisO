<?php

use Faker\Generator as Faker;

$factory->define(App\PacticipacionGanador::class, function (Faker $faker) {
    return [
        //
    ];
});
