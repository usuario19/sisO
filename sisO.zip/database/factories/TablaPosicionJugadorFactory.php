<?php

use Faker\Generator as Faker;

$factory->define(App\Tabla_Posicion_Jugador::class, function (Faker $faker) {
    return [
        //
    ];
});
